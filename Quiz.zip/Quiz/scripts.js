let qum = document.getElementById("qum");
let qdois = document.getElementById("qdois");
let qtres = document.getElementById("qtres");
let passe = document.getElementById("passe");

function mudacorQum() {
    qum.style.backgroundColor = "green";
}

function mudacorQdois() {
    qdois.style.backgroundColor = "green";
}

function mudacorQtres() {
    qtres.style.backgroundColor = "green";
}

function verificador() {
          if(qum.style.backgroundColor === "green" && qdois.style.backgroundColor === "red" && qtres.style.backgroundColor === "green") {
        passe.style.display = "flex"
    }
    else {
        qum.style.backgroundColor = "red";
        qdois.style.backgroundColor = "red";
        qtres.style.backgroundColor = "red";
    }
}